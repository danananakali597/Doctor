import test from 'node:test';
import assert from 'node:assert/strict';
import {buildLogEmbed,logSeverity} from '../src/log-design.js';
import {logDefaults,mergeLogs} from '../src/log-catalog.js';
test('ordinary moderation warns; detected destructive bursts and scams escalate',()=>{
 assert.equal(logSeverity('message_edited'),'normal');
 assert.equal(logSeverity('member_banned'),'warning');
 assert.equal(logSeverity('security_incident'),'danger');
 assert.equal(logSeverity('join_protection',{rules:'age, raid'}),'danger');
 assert.equal(logSeverity('message_violation',{rules:'spam'}),'warning');
 assert.equal(logSeverity('message_violation',{rules:'scam'}),'danger');
 const rules=mergeLogs(logDefaults(),{member_banned:{enabled:true,color:'#000000'}});
 assert.equal(rules.member_banned.color,'#f39c12');assert.equal(rules.member_banned.enabled,true);
});
test('embeds use readable mentions without guessing target type and stay within limits',()=>{
 const embed=buildLogEmbed({},'security_incident',{actor:'123456789012345678',channel:'123456789012345679',target:'123456789012345680',...Object.fromEntries(Array.from({length:20},(_,i)=>['long_'+i,'x'.repeat(1000)]))});
 assert.equal(embed.color,0xe74c3c);
 assert.equal(embed.fields[0].value,'<@123456789012345678>');
 assert.equal(embed.fields[1].value,'<#123456789012345679>');
 assert.equal(embed.fields[2].value,'123456789012345680');
 assert.ok(embed.fields.reduce((n,f)=>n+f.name.length+f.value.length,embed.title.length+embed.footer.text.length)<6000);
 assert.ok(embed.fields.length<=25);
});
