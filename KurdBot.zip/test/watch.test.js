import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'vex-watch-'));
const {createWatch,watch,validateWatch}=await import('../src/watch.js');
const {db}=await import('../src/db.js');
test('each viewer can choose a direct or public YouTube video',()=>{
 const a=createWatch('https://vex.example','guild','alice','https://example.com/movie.mp4','Example');
 const b=createWatch('https://vex.example','guild','bob','https://youtu.be/dQw4w9WgXcQ','Music');
 assert.notEqual(a.id,b.id);
 assert.equal(watch(a.id).url,'https://example.com/movie.mp4');
 assert.equal(watch(b.id).youtubeId,'dQw4w9WgXcQ');
 assert.equal(watch('invalid'),null);
});
test('unsafe or malformed video links are rejected',()=>{
 assert.throws(()=>validateWatch('http://example.com/video.mp4'),/HTTPS/);
 assert.throws(()=>validateWatch('https://user:pass@example.com/video.mp4'),/HTTPS/);
 assert.throws(()=>validateWatch('https://youtube.com/watch?v=bad'),/YouTube/);
});
test.after(()=>{db.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});
