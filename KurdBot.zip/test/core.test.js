import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'kurdbot-test-'));
const {cleanSettings,settings,saveSettings,event,events,warn,warnings,saveTurns,turns}=await import('../src/db.js');
test('settings reject unknown modes and malformed channels while preserving valid fields',()=>{
  const id='123456789012345678';
  const s=saveSettings(id,{aiEnabled:false,safetyMode:'anything',logsChannelId:'<script>',personality:'A'.repeat(2000)});
  assert.equal(s.aiEnabled,false);assert.equal(s.safetyMode,'review');assert.equal(s.logsChannelId,'');assert.equal(s.personality.length,1000);
  assert.deepEqual(settings(id),s);
});
test('logs, warnings and bounded conversation context remain scoped per server',()=>{
  event('one','join',{userId:'u'});warn('one','u','mod','reason');
  assert.equal(events('one').length,2);assert.equal(events('two').length,0);
  assert.equal(warnings('one','u')[0].reason,'reason');assert.equal(warnings('two','u').length,0);
  saveTurns('one','channel','u',Array.from({length:15},(_,n)=>({role:'user',content:String(n)})));
  assert.equal(turns('one','channel','u').length,10);assert.equal(turns('two','channel','u').length,0);
});
test.after(()=>fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true}));
