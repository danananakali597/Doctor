import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import crypto from 'node:crypto';import {PermissionFlagsBits as P,Collection} from 'discord.js';
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'vex-http-'));process.env.PUBLIC_URL='http://localhost:3000';process.env.DISCORD_CLIENT_ID='123456789012345678';
const {app}=await import('../src/web.js');const {client}=await import('../src/bot.js');const {setSession,grant,settings,db}=await import('../src/db.js');
const id='123456789012345678',sid='session-test',csrf='csrf-test';let permission=P.ManageGuild;
const member={id:'user',permissions:{has:p=>(permission&p)===p},roles:{cache:new Collection()}};
const guild={id,name:'Test',ownerId:'owner',members:{fetch:async()=>member},channels:{cache:new Collection()},roles:{cache:new Collection()}};client.guilds.cache.set(id,guild);
setSession(crypto.createHash('sha256').update(sid).digest('hex'),{user:{id:'user',username:'test'},csrf,guilds:[]},Date.now()+60000);
const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
const headers={cookie:'sid='+sid,origin:'http://localhost:3000','x-csrf-token':csrf,'content-type':'application/json'};
const put=(body,extra={})=>fetch(base+'/api/guilds/'+id+'/settings',{method:'PUT',headers:{...headers,...extra},body:JSON.stringify(body)});
test('anonymous settings writes are rejected',async()=>assert.equal((await put({}, {cookie:''})).status,401));
test('CSRF rejects cross-origin writes',async()=>assert.equal((await put({},{origin:'https://evil.example'})).status,403));
test('Manage Server alone cannot weaken protection',async()=>assert.equal((await put({modules:{spam:{enabled:true}}})).status,403));
test('fresh Discord permissions are checked for every request',async()=>{permission=0n;assert.equal((await put({})).status,403);permission=P.ManageGuild|P.Administrator;});
test('forged premium settings rejected even for administrator',async()=>{const r=await put({modules:{nuke:{enabled:true}}});assert.equal(r.status,400);assert.equal(settings(id).modules.nuke.enabled,false);});
test('administrator can save permitted Basic settings',async()=>{assert.equal((await put({modules:{spam:{enabled:true,action:'log'}}})).status,200);assert.equal(settings(id).modules.spam.enabled,true);});
test('administrator cannot add trusted users without ownership',async()=>{grant(id,'plus',Date.now()+60000);assert.equal((await put({trustedUsers:['123456789012345679']})).status,400);});
test('guild lookup cannot access another server',async()=>{const r=await fetch(base+'/api/guilds/223456789012345678',{headers});assert.equal(r.status,403);});
test('non-operator cannot mint a trial',async()=>{const r=await fetch(base+'/api/guilds/'+id+'/trial',{method:'POST',headers,body:JSON.stringify({plan:'ultimate'})});assert.equal(r.status,403);});
test('removed cinema and watch routes stay unavailable',async()=>{
 for(const url of ['/api/cinema/'+id,'/cinema/'+id,'/watch','/api/watch/example','/activity/','/activity/api/room']){const r=await fetch(base+url,{headers});assert.equal(r.status,404,url);}
});
test('enabled logs require an accessible same-server channel and sending permissions',async()=>{
 permission=P.ManageGuild|P.Administrator;
 const channelId='323456789012345678';const body={activityLogs:{role_created:{enabled:true,channelId,color:'#aa00ff'}}};
 assert.equal((await put(body)).status,400);
 let allowed=false;guild.members.me={id:'bot'};guild.channels.cache.set(channelId,{id:channelId,type:0,permissionsFor:()=>({has:()=>allowed})});
 assert.equal((await put(body)).status,400);allowed=true;assert.equal((await put(body)).status,200);
 assert.equal(settings(id).activityLogs.role_created.color,'#aa00ff');
 assert.equal((await put({activityLogs:{role_created:{channelId:''}}})).status,400);
});
test.after(async()=>{await new Promise(r=>server.close(r));client.destroy();db.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});
