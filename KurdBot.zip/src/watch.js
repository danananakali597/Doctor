import crypto from 'node:crypto';
import {db} from './db.js';

db.exec('CREATE TABLE IF NOT EXISTS watches(id TEXT PRIMARY KEY, guild TEXT NOT NULL, creator TEXT NOT NULL, json TEXT NOT NULL, expires INTEGER NOT NULL)');
const lifetime=7*86400000;
export function validateWatch(input,title=''){
 if(typeof input!=='string'||input.length>1000)throw Error('Send a video link shorter than 1,000 characters.');
 let url;try{url=new URL(input);}catch{throw Error('Send a valid video link.');}
 if(url.protocol!=='https:'||url.username||url.password)throw Error('Use an HTTPS video link.');
 if(typeof title!=='string'||title.length>100)throw Error('Movie title is too long.');
 const host=url.hostname.toLowerCase();let youtubeId=null;
 if(['youtu.be','youtube.com','www.youtube.com','m.youtube.com'].includes(host)){
  youtubeId=host==='youtu.be'?url.pathname.slice(1):url.searchParams.get('v');
  if(!/^[a-zA-Z0-9_-]{11}$/.test(youtubeId||''))throw Error('Send a valid public YouTube video URL.');
 }else if(!url.hostname.includes('.')||url.hash||/(?:^|\.)(?:localhost|local|internal|test)$/.test(host))throw Error('Send a public direct HTTPS video URL.');
 return {title:title.trim()||'Your video',url:url.href,youtubeId};
}
export function createWatch(base,guild,creator,input,title=''){
 const movie=validateWatch(input,title),id=crypto.randomBytes(15).toString('base64url');
 db.prepare('DELETE FROM watches WHERE expires<?').run(Date.now());
 db.prepare('INSERT INTO watches VALUES (?,?,?,?,?)').run(id,guild,creator,JSON.stringify(movie),Date.now()+lifetime);
 return {id,link:base+'/watch/'+id,...movie};
}
export function watch(id){if(!/^[A-Za-z0-9_-]{20}$/.test(id))return null;const r=db.prepare('SELECT json FROM watches WHERE id=? AND expires>?').get(id,Date.now());return r?JSON.parse(r.json):null;}
