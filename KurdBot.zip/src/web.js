import express from 'express';
import crypto from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {PermissionsBitField} from 'discord.js';
import {env} from './config.js';
import {client} from './bot.js';
import {settings,saveSettings,events} from './db.js';

const app=express();app.disable('x-powered-by');app.use(express.json({limit:'20kb'}));
const sessions=new Map(),states=new Map();
const secure=env.publicUrl.startsWith('https://');
function cookie(req,name){return req.headers.cookie?.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1);}
function newToken(){return crypto.randomBytes(32).toString('hex');}
function session(req){const token=cookie(req,'sid');const s=sessions.get(token);if(s && s.expires>Date.now()) return s;}
function auth(req,res,next){req.session=session(req);if(!req.session)return res.status(401).json({error:'Login required'});next();}
function csrf(req,res,next){if(req.get('origin')!==env.publicUrl || req.get('x-csrf-token')!==req.session.csrf)return res.status(403).json({error:'Invalid request token'});next();}
function allowed(s,id){return s.guilds.some(g=>g.id===id && (BigInt(g.permissions)&PermissionsBitField.Flags.ManageGuild)!==0n) && client.guilds.cache.has(id);}
async function guildAuth(req,res,next){
  if(!/^\d{17,22}$/.test(req.params.id)||!allowed(req.session,req.params.id))return res.status(403).json({error:'No access to this server'});
  try {
    const guild=client.guilds.cache.get(req.params.id);
    const member=await guild.members.fetch({user:req.session.user.id,force:true});
    if(!member.permissions.has(PermissionsBitField.Flags.ManageGuild))return res.status(403).json({error:'Manage Server permission required'});
    next();
  } catch(e) {res.status(403).json({error:'Could not verify server permission'});}
}
async function discord(url,options={}) {const r=await fetch(`https://discord.com/api/v10${url}`,options);if(!r.ok)throw new Error(`Discord API ${r.status}`);return r.json();}
app.get('/auth/login',(req,res)=>{
  const state=newToken();states.set(state,Date.now()+300000);
  const q=new URLSearchParams({client_id:env.clientId,redirect_uri:env.redirectUri,response_type:'code',scope:'identify guilds',state});
  res.redirect(`https://discord.com/oauth2/authorize?${q}`);
});
app.get('/auth/callback',async(req,res)=>{
  const state=String(req.query.state||'');const expiry=states.get(state);states.delete(state);
  if(!expiry||expiry<Date.now()||typeof req.query.code!=='string')return res.status(400).send('Invalid or expired login');
  try {
    const body=new URLSearchParams({client_id:env.clientId,client_secret:env.clientSecret,grant_type:'authorization_code',code:req.query.code,redirect_uri:env.redirectUri});
    const token=await discord('/oauth2/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body});
    const headers={Authorization:`Bearer ${token.access_token}`};
    const [user,guilds]=await Promise.all([discord('/users/@me',{headers}),discord('/users/@me/guilds',{headers})]);
    const id=newToken(),csrfToken=newToken();sessions.set(id,{user:{id:user.id,username:user.username},guilds,csrf:csrfToken,expires:Date.now()+86400000});
    res.setHeader('Set-Cookie',`sid=${id}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400${secure?'; Secure':''}`);
    res.redirect('/');
  } catch(e){console.error('OAuth:',e);res.status(502).send('Discord login failed');}
});
app.post('/auth/logout',auth,csrf,(req,res)=>{sessions.delete(cookie(req,'sid'));res.setHeader('Set-Cookie',`sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure?'; Secure':''}`);res.json({ok:true});});
app.get('/api/me',auth,(req,res)=>res.json({user:req.session.user,csrf:req.session.csrf,clientId:env.clientId,guilds:req.session.guilds.filter(g=>allowed(req.session,g.id)).map(g=>({id:g.id,name:g.name,icon:g.icon}))}));
app.get('/api/guilds/:id',auth,guildAuth,(req,res)=>{
  const guild=client.guilds.cache.get(req.params.id);
  res.json({guild:{id:guild.id,name:guild.name,memberCount:guild.memberCount},settings:settings(guild.id),channels:guild.channels.cache.filter(c=>c.isTextBased()&&!c.isThread()).map(c=>({id:c.id,name:c.name})),events:events(guild.id)});
});
app.put('/api/guilds/:id/settings',auth,csrf,guildAuth,(req,res)=>{
  if(!req.body||typeof req.body!=='object'||Array.isArray(req.body))return res.status(400).json({error:'Invalid settings'});
  const guild=client.guilds.cache.get(req.params.id);
  for(const field of ['aiChannelId','logsChannelId']) if(req.body[field] && !guild.channels.cache.get(req.body[field])?.isTextBased())return res.status(400).json({error:`Invalid ${field}`});
  res.json({settings:saveSettings(req.params.id,req.body)});
});
app.get('/health',(_req,res)=>res.json({ok:client.isReady()}));
app.use((_req,res,next)=>{res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' https://cdn.discordapp.com data:; base-uri 'none'; frame-ancestors 'none'");res.setHeader('X-Content-Type-Options','nosniff');next();});
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)),'../public')));
app.use((err,_req,res,_next)=>{console.error('Web:',err);res.status(500).json({error:'Internal error'});});
export function startWeb(){return app.listen(env.port,()=>console.log(`Dashboard: ${env.publicUrl}`));}
