import express from 'express';
import crypto from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {PermissionFlagsBits as P} from 'discord.js';
import {env} from './config.js';
import {client} from './bot.js';
import {settings,saveSettings,plan,events,getState,setSession,getSession,deleteSession,grant} from './db.js';
import {modules,validatePatch,entitled} from './catalog.js';
import {record,verifyMember} from './security.js';
import {scan,backup,restore,restoreConfiguration,lockdown} from './operations.js';
import {WindowCounter} from './rules.js';
import {room,updateRoom} from './cinema.js';
export const app=express();app.disable('x-powered-by');app.set('trust proxy',1);app.use(express.json({limit:'40kb'}));
const attempts=new WindowCounter(),states=new Map(),secure=env.publicUrl.startsWith('https://'),nonce=()=>crypto.randomBytes(32).toString('hex');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
function cookie(req,key){return req.headers.cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith(key+'='))?.slice(key.length+1)||'';}
const setCookie=(name,value,maxAge)=>`${name}=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure?'; Secure':''}`;
app.use((req,res,next)=>{res.set({'Content-Security-Policy':"default-src 'self'; img-src 'self' https://cdn.discordapp.com; style-src 'self'; script-src 'self'; media-src https:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'});if(req.path.startsWith('/api')||req.path.startsWith('/auth'))res.set('Cache-Control','no-store');next();});
function auth(req,res,next){req.session=getSession(hash(cookie(req,'sid')));if(!req.session)return res.status(401).json({error:'Please sign in again.'});next();}
function csrf(req,res,next){if(req.get('origin')!==env.publicUrl||req.get('x-csrf-token')!==req.session.csrf)return res.status(403).json({error:'Invalid request token'});if(attempts.hit(req.session.user.id+':write',60).length>40)return res.status(429).json({error:'Please wait before making more changes.'});next();}
const ownerId=()=>client.application?.owner?.ownerId||client.application?.owner?.id;
const adminPerm=permissions=>(BigInt(permissions)&(P.ManageGuild|P.Administrator))!==0n;
async function guildAuth(req,res,next){try{if(!/^\d{17,22}$/.test(req.params.id))throw Error('Invalid server');const g=client.guilds.cache.get(req.params.id);if(!g)throw Error('Bot is not in this server');const m=await g.members.fetch({user:req.session.user.id,force:true});if(!m.permissions.has(P.ManageGuild))throw Error('Manage Server permission required');req.guild=g;req.member=m;next();}catch(e){res.status(403).json({error:e.message});}}
function owner(req,res,next){if(req.member.id!==req.guild.ownerId)return res.status(403).json({error:'Server owner required'});next();}
async function discord(url,opts={}){const r=await fetch('https://discord.com/api/v10'+url,{...opts,signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error('Discord sign-in failed; please retry');return r.json();}
app.get('/auth/login',(req,res)=>{if(attempts.hit(req.ip+':login',60).length>10)return res.status(429).send('Please try again in a minute.');for(const[k,v]of states)if(v.until<Date.now())states.delete(k);const state=nonce(),binding=nonce(),back=typeof req.query.back==='string'&&/^\/cinema\/\d{17,22}$/.test(req.query.back)?req.query.back:'/';states.set(hash(state),{binding:hash(binding),until:Date.now()+300000,back});res.setHeader('Set-Cookie',setCookie('oauth',binding,300));res.redirect('https://discord.com/oauth2/authorize?'+new URLSearchParams({client_id:env.clientId,redirect_uri:env.redirectUri,response_type:'code',scope:'identify guilds',state}));});
app.get('/auth/callback',async(req,res)=>{const key=hash(String(req.query.state||'')),s=states.get(key);states.delete(key);if(!s||s.until<Date.now()||s.binding!==hash(cookie(req,'oauth'))||typeof req.query.code!=='string')return res.status(400).send('Login expired. Return to the homepage and sign in again.');try{const token=await discord('/oauth2/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:env.clientId,client_secret:env.clientSecret,grant_type:'authorization_code',code:req.query.code,redirect_uri:env.redirectUri})});const headers={Authorization:`Bearer ${token.access_token}`};const[u,guilds]=await Promise.all([discord('/users/@me',{headers}),discord('/users/@me/guilds',{headers})]);const id=nonce();setSession(hash(id),{user:{id:u.id,username:u.username},guilds,csrf:nonce()},Date.now()+86400000);res.setHeader('Set-Cookie',[setCookie('sid',id,86400),setCookie('oauth','',0)]);res.redirect(s.back||'/');}catch(e){console.error('OAuth error:',e.message);res.status(502).send('Discord login failed. Please retry from the homepage.');}});
app.post('/auth/logout',auth,csrf,(req,res)=>{deleteSession(hash(cookie(req,'sid')));res.setHeader('Set-Cookie',setCookie('sid','',0));res.json({ok:true});});
const invite=()=> 'https://discord.com/oauth2/authorize?'+new URLSearchParams({client_id:env.clientId,scope:'bot applications.commands',permissions:(P.ViewChannel|P.SendMessages|P.EmbedLinks|P.ReadMessageHistory|P.ManageMessages|P.ModerateMembers|P.KickMembers|P.ViewAuditLog|P.ManageChannels|P.ManageRoles|P.MoveMembers).toString()});
app.get('/api/public',(_req,res)=>res.json({invite:invite()}));
app.get('/api/me',auth,(req,res)=>res.json({user:req.session.user,csrf:req.session.csrf,invite:invite(),operator:req.session.user.id===ownerId(),guilds:req.session.guilds.filter(g=>g.owner||adminPerm(g.permissions)).map(g=>({id:g.id,name:g.name,icon:g.icon,installed:client.guilds.cache.has(g.id)}))}));
async function cinemaAuth(req,res,next){try{if(!/^\d{17,22}$/.test(req.params.id))throw Error('Invalid server');const guild=client.guilds.cache.get(req.params.id);if(!guild)throw Error('Cinema server unavailable');const member=await guild.members.fetch({user:req.session.user.id,force:true});req.guild=guild;req.member=member;next();}catch(e){res.status(403).json({error:e.message});}}
app.get('/api/cinema/:id',auth,cinemaAuth,(req,res)=>res.json({room:room(req.guild.id),guild:{id:req.guild.id,name:req.guild.name},user:req.session.user,csrf:req.session.csrf,host:req.member.permissions.has(P.ManageGuild)}));
app.post('/api/cinema/:id',auth,csrf,cinemaAuth,(req,res)=>{if(!req.member.permissions.has(P.ManageGuild))return res.status(403).json({error:'Manage Server required'});try{const next=updateRoom(req.guild.id,req.body||{});res.json({room:next});}catch(e){res.status(400).json({error:e.message});}});
app.get('/cinema/:id',(req,res)=>{if(!/^\d{17,22}$/.test(req.params.id))return res.sendStatus(404);res.sendFile(path.join(path.dirname(fileURLToPath(import.meta.url)),'../public/cinema.html'));});
app.get('/api/guilds/:id',auth,guildAuth,(req,res)=>{const g=req.guild,p=plan(g.id),b=getState(g.id,'backup');res.json({guild:{id:g.id,name:g.name,memberCount:g.memberCount,owner:req.member.id===g.ownerId},plan:p,modules,settings:settings(g.id),channels:g.channels.cache.filter(c=>!c.isThread()).map(c=>({id:c.id,name:c.name,type:c.type})),roles:g.roles.cache.filter(r=>r.id!==g.id).map(r=>({id:r.id,name:r.name})),events:events(g.id),scan:entitled(p,'scanner')?scan(g):null,backup:b?{at:b.at,roles:b.roles.length,channels:b.channels.length}:null,locked:Object.keys(getState(g.id,'lockdown',{})),botReady:client.isReady(),persistent:!!process.env.RAILWAY_VOLUME_MOUNT_PATH});});
app.put('/api/guilds/:id/settings',auth,csrf,guildAuth,async(req,res)=>{
 if(!req.member.permissions.has(P.Administrator))return res.status(403).json({error:'Administrator required to change security settings'});
 const patch=validatePatch(req.body,plan(req.guild.id),req.member.id===req.guild.ownerId),g=req.guild;
 if(patch.logsChannelId){const c=g.channels.cache.get(patch.logsChannelId);if(!c?.isTextBased()||c.isThread())return res.status(400).json({error:'Choose a text channel in this server'});}
 for(const k of ['exemptChannels','protectedChannels','lockdownChannels'])if(patch[k]?.some(id=>!g.channels.cache.has(id)))return res.status(400).json({error:'Unknown server channel'});
 for(const k of ['exemptRoles','trustedRoles','protectedRoles'])if(patch[k]?.some(id=>!g.roles.cache.has(id)||id===g.id))return res.status(400).json({error:'Unknown role or @everyone is not allowed'});
 const changed=Object.keys(patch.modules||{});const updated=saveSettings(g.id,patch);await record(g,'settings_updated',{actor:req.member.id,modules:changed.join(', ')||'access / routing'},true);res.json({settings:updated});
});
app.post('/api/guilds/:id/action',auth,csrf,guildAuth,async(req,res)=>{
 const {action}=req.body||{},g=req.guild;let result;
 if(action==='scan'){if(!entitled(plan(g.id),'scanner'))return res.status(403).json({error:'Ultimate required'});result=scan(g);}
 else if(action==='verify'){if(!req.member.permissions.has(P.ModerateMembers))return res.status(403).json({error:'Moderate Members required'});if(!/^\d{17,22}$/.test(req.body.memberId))throw Error('Invalid member ID');await verifyMember(g,req.member,await g.members.fetch(req.body.memberId));result={message:'Member approved'};}
 else{if(req.member.id!==g.ownerId)return res.status(403).json({error:'Server owner required'});
 if(action==='backup')result=await backup(g,req.member.id);
 else if(action==='restore'){if(req.body.confirm!==g.name)throw Error('Type the server name to confirm');result=await restore(g,req.member.id);}
 else if(action==='restore-settings'){if(req.body.confirm!==g.name)throw Error('Type the server name to confirm');result=await restoreConfiguration(g,req.member.id);}
 else if(action==='lock'||action==='unlock'){if(req.body.confirm!==g.name)throw Error('Type the server name to confirm');result=await lockdown(g,action==='lock',req.member.id);}
 else throw Error('Unknown action');}res.json({result});
});
app.get('/api/guilds/:id/report',auth,guildAuth,(req,res)=>{if(!entitled(plan(req.guild.id),'reports'))return res.status(403).json({error:'Ultimate required'});res.attachment('vex-incident-report.json').json({guild:req.guild.id,generatedAt:new Date().toISOString(),events:events(req.guild.id,1000)});});
// Only the Discord application owner may issue manual trial entitlements. No paid checkout is represented as active.
app.post('/api/guilds/:id/trial',auth,csrf,guildAuth,async(req,res)=>{if(req.session.user.id!==ownerId())return res.status(403).json({error:'VEX application owner required'});const p=req.body.plan;if(!['basic','plus','ultimate'].includes(p))throw Error('Invalid plan');grant(req.guild.id,p,Date.now()+7*86400000);await record(req.guild,'trial_granted',{actor:req.member.id,plan:p,days:7});res.json({ok:true});});
app.get('/health',(_req,res)=>res.status(client.isReady()?200:503).json({ok:client.isReady(),version:'2.0.0'}));
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)),'../public')));
app.use((err,_req,res,_next)=>{console.error('Web error:',err.message);res.status(400).json({error:err.message||'Request failed'});});
export function startWeb(){return app.listen(env.port,()=>console.log('VEX dashboard: '+env.publicUrl));}
