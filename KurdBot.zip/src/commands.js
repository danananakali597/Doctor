import {SlashCommandBuilder,PermissionFlagsBits} from 'discord.js';
const mod=PermissionFlagsBits.ModerateMembers;
export const commands=[
  new SlashCommandBuilder().setName('help').setDescription('Show KurdBot commands'),
  new SlashCommandBuilder().setName('ping').setDescription('Check bot latency'),
  new SlashCommandBuilder().setName('ai').setDescription('Ask KurdBot').addStringOption(o=>o.setName('question').setDescription('Your question').setRequired(true)),
  new SlashCommandBuilder().setName('voice').setDescription('AI voice channel').addSubcommand(s=>s.setName('join').setDescription('Join your voice channel and announce listening')).addSubcommand(s=>s.setName('leave').setDescription('Stop listening and leave')),
  new SlashCommandBuilder().setName('warn').setDescription('Warn a member').setDefaultMemberPermissions(mod).addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason').setRequired(true)),
  new SlashCommandBuilder().setName('warnings').setDescription('Show warnings').setDefaultMemberPermissions(mod).addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)),
  new SlashCommandBuilder().setName('clear').setDescription('Delete recent messages (up to 100, younger than 14 days)').setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages).addIntegerOption(o=>o.setName('count').setDescription('1–100').setMinValue(1).setMaxValue(100).setRequired(true)),
  new SlashCommandBuilder().setName('timeout').setDescription('Timeout a member').setDefaultMemberPermissions(mod).addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)).addIntegerOption(o=>o.setName('minutes').setDescription('1–10080').setMinValue(1).setMaxValue(10080).setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  new SlashCommandBuilder().setName('kick').setDescription('Kick a member').setDefaultMemberPermissions(PermissionFlagsBits.KickMembers).addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  new SlashCommandBuilder().setName('ban').setDescription('Ban a member').setDefaultMemberPermissions(PermissionFlagsBits.BanMembers).addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  new SlashCommandBuilder().setName('serverinfo').setDescription('Server information'),
  new SlashCommandBuilder().setName('userinfo').setDescription('Member information').addUserOption(o=>o.setName('member').setDescription('Member'))
].map(c=>c.toJSON());
