import {getState,setState} from './db.js';

const empty=()=>({title:'',url:'',playing:false,position:0,updatedAt:Date.now(),revision:0});
export function room(guildId){return getState(guildId,'cinema',empty());}
export function validateMovie(input){
 if(typeof input.title!=='string'||input.title.trim().length<2||input.title.length>120)throw Error('Enter a movie title (2–120 characters).');
 if(typeof input.url!=='string'||input.url.length>1800)throw Error('Enter a direct HTTPS video URL.');
 let url;try{url=new URL(input.url);}catch{throw Error('Invalid video URL.');}
 if(url.protocol!=='https:'||url.username||url.password||url.hash||!url.hostname.includes('.')||/(?:^|\.)(?:localhost|local|internal|test)$/.test(url.hostname))throw Error('Use a public HTTPS video URL without credentials.');
 return {title:input.title.trim(),url:url.href};
}
export function position(r,now=Date.now()){return Math.max(0,r.position+(r.playing?Math.max(0,now-r.updatedAt)/1000:0));}
export function updateRoom(guildId,input){
 const previous=room(guildId),now=Date.now();let next;
 if(input.action==='set'){const media=validateMovie(input);next={...previous,...media,playing:false,position:0};}
 else if(input.action==='play'){if(!previous.url)throw Error('Set a movie first.');next={...previous,playing:true,position:position(previous,now)};}
 else if(input.action==='pause'){next={...previous,playing:false,position:position(previous,now)};}
 else if(input.action==='seek'){if(!previous.url||!Number.isFinite(input.position)||input.position<0||input.position>86400)throw Error('Invalid playback position.');next={...previous,position:input.position};}
 else if(input.action==='end')next=empty();
 else throw Error('Unknown cinema action.');
 next.updatedAt=now;next.revision=previous.revision+1;setState(guildId,'cinema',next);return next;
}
