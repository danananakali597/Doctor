import {getState,setState} from './db.js';

const empty=()=>({title:'',url:'',playing:false,position:0,scheduledAt:null,updatedAt:Date.now(),revision:0});
export function room(guildId){return getState(guildId,'cinema',empty());}
export function validateMovie(input){
 if(typeof input.title!=='string'||input.title.trim().length<2||input.title.length>120)throw Error('Enter a movie title (2–120 characters).');
 if(typeof input.url!=='string'||input.url.length>1800)throw Error('Enter a direct HTTPS video URL.');
 let url;try{url=new URL(input.url);}catch{throw Error('Invalid video URL.');}
 if(url.protocol!=='https:'||url.username||url.password||url.hash||!url.hostname.includes('.')||/(?:^|\.)(?:localhost|local|internal|test)$/.test(url.hostname)||!/\.(?:mp4|webm|ogv)$/i.test(url.pathname))throw Error('Use a public direct HTTPS .mp4, .webm or .ogv video URL (not a movie website page).');
 return {title:input.title.trim(),url:url.href};
}
export function position(r,now=Date.now()){return Math.max(0,r.position+(r.playing?Math.max(0,now-r.updatedAt)/1000:0));}
export function playback(r,now=Date.now()){
 const scheduled=Number.isSafeInteger(r.scheduledAt)&&r.scheduledAt>0;
 if(scheduled&&now<r.scheduledAt)return {...r,playing:false,position:0,waiting:true};
 if(scheduled&&r.playing)return {...r,position:Math.max(0,(now-Math.max(r.scheduledAt,r.updatedAt))/1000+r.position),updatedAt:now,waiting:false};
 return {...r,position:position(r,now),updatedAt:now,waiting:false};
}
export function updateRoom(guildId,input){
 const previous=room(guildId),now=Date.now();let next;
 if(input.action==='set'||input.action==='schedule'){
  const media=validateMovie(input);
  const scheduledAt=input.action==='schedule'?Number(input.scheduledAt):null;
  if(input.action==='schedule'&&(!Number.isSafeInteger(scheduledAt)||scheduledAt<now+60000||scheduledAt>now+90*86400000))throw Error('Choose a start time from one minute to 90 days in the future.');
  next={...previous,...media,playing:input.action==='schedule',scheduledAt,position:0};
 }
 else if(input.action==='play'){if(!previous.url)throw Error('Set a movie first.');next={...previous,playing:true,scheduledAt:null,position:playback(previous,now).position};}
 else if(input.action==='pause'){next={...previous,playing:false,scheduledAt:null,position:playback(previous,now).position};}
 else if(input.action==='seek'){if(!previous.url||!Number.isFinite(input.position)||input.position<0||input.position>86400)throw Error('Invalid playback position.');next={...previous,scheduledAt:null,position:input.position};}
 else if(input.action==='end')next=empty();
 else throw Error('Unknown cinema action.');
 next.updatedAt=now;next.revision=previous.revision+1;setState(guildId,'cinema',next);return next;
}
