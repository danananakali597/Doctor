import {Client,GatewayIntentBits,Events,AuditLogEvent,PermissionsBitField} from 'discord.js';
import {commands} from './commands.js';
import {settings,event,warn,warnings} from './db.js';
import {answer,unsafeMessage,ai} from './ai.js';
import {joinVoice,leaveVoice} from './voice.js';
import {env} from './config.js';

export const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent,GatewayIntentBits.GuildVoiceStates,GatewayIntentBits.GuildModeration]});
async function log(guild,kind,detail) {
  event(guild.id,kind,detail);
  const id=settings(guild.id).logsChannelId;
  if (!id) return;
  const channel=await guild.channels.fetch(id).catch(()=>null);
  if (channel?.isTextBased()) await channel.send({content:`**${kind}** • ${Object.entries(detail).map(([k,v])=>`${k}: ${String(v).slice(0,160)}`).join(' • ')}`.slice(0,1900),allowedMentions:{parse:[]}}).catch(()=>{});
}
client.once(Events.ClientReady,async c=>{
  console.log(`Ready as ${c.user.tag}`);
  await c.application.commands.set(commands).catch(e=>console.error('Register commands:',e));
});
client.on(Events.GuildMemberAdd,m=>{void log(m.guild,'join',{userId:m.id,name:m.user.username});});
client.on(Events.GuildMemberRemove,async m=>{
  await new Promise(r=>setTimeout(r,1200));
  let kicked=false;
  if (m.guild.members.me?.permissions.has(PermissionsBitField.Flags.ViewAuditLog)) {
    const entries=await m.guild.fetchAuditLogs({type:AuditLogEvent.MemberKick,limit:5}).catch(()=>null);
    kicked=entries?.entries.some(e=>e.target?.id===m.id && Date.now()-e.createdTimestamp<10000) || false;
  }
  await log(m.guild,kicked?'kick':'leave',{userId:m.id,name:m.user.username});
});
client.on(Events.GuildBanAdd,b=>{void log(b.guild,'ban',{userId:b.user.id,name:b.user.username});});
client.on(Events.MessageDelete,m=>{if(m.guild && !m.author?.bot) void log(m.guild,'message_deleted',{userId:m.author?.id||'unknown',channelId:m.channelId,messageId:m.id});});
client.on(Events.MessageUpdate,(oldM,newM)=>{if(newM.guild && !newM.author?.bot && oldM.content!==newM.content) void log(newM.guild,'message_edited',{userId:newM.author?.id||'unknown',channelId:newM.channelId,messageId:newM.id});});
client.on(Events.GuildMemberUpdate,(before,after)=>{
  const a=before.roles.cache.map(r=>r.id).sort().join(',');const b=after.roles.cache.map(r=>r.id).sort().join(',');
  if(a!==b) void log(after.guild,'roles_changed',{userId:after.id,oldRoles:a,newRoles:b});
  if(before.communicationDisabledUntilTimestamp!==after.communicationDisabledUntilTimestamp) void log(after.guild,'timeout_changed',{userId:after.id,until:after.communicationDisabledUntilTimestamp||'removed'});
});
client.on(Events.MessageCreate,async m=>{
  if(!m.guild || m.author.bot || !m.content) return;
  const s=settings(m.guild.id);
  if(s.safetyEnabled && ai) {
    try {
      if(await unsafeMessage(m.content)) {
        if(s.safetyMode==='delete') {
          if(m.deletable) {await m.delete(); await log(m.guild,'safety_deleted',{userId:m.author.id,channelId:m.channelId,messageId:m.id,reason:'Targeted abuse'}); return;}
        }
        await log(m.guild,'safety_review',{userId:m.author.id,channelId:m.channelId,messageId:m.id,reason:'Possible targeted abuse'});
      }
    } catch(e) {console.error('Safety check:',e.message);}
  }
  if(!s.aiEnabled || !ai || (s.aiChannelId && s.aiChannelId!==m.channelId) || !m.mentions.has(client.user)) return;
  try {await m.channel.sendTyping(); const text=m.content.replace(new RegExp(`<@!?${client.user.id}>`,'g'),'').trim(); if(text) await m.reply({content:await answer(m.guild.id,m.channelId,m.author.id,text,s.personality),allowedMentions:{repliedUser:false,parse:[]}});}
  catch(e){console.error('Mention AI:',e);await m.reply('AI is temporarily unavailable.').catch(()=>{});}
});
client.on(Events.InteractionCreate,async i=>{
  if(!i.isChatInputCommand() || !i.guild) return;
  const s=settings(i.guildId), user=i.options.getUser('member'), reason=i.options.getString('reason')||'No reason provided';
  const reply=async content=>i.replied||i.deferred?i.editReply(content):i.reply({content,ephemeral:true});
  try {
    switch(i.commandName) {
      case 'help': return reply('`/ai` `/voice join|leave` `/ping` `/userinfo` `/serverinfo` • moderators: `/warn` `/warnings` `/clear` `/timeout` `/kick` `/ban`');
      case 'ping': return reply(`Pong • ${client.ws.ping} ms`);
      case 'serverinfo': return reply(`${i.guild.name} • ${i.guild.memberCount} members • ID ${i.guildId}`);
      case 'userinfo': {const u=user||i.user;return reply(`${u.username} • ID ${u.id}`);}
      case 'ai': {
        if(!s.aiEnabled || (s.aiChannelId && s.aiChannelId!==i.channelId)) return reply('AI is disabled in this channel.');
        await i.deferReply(); return i.editReply(await answer(i.guildId,i.channelId,i.user.id,i.options.getString('question'),s.personality));
      }
      case 'voice': {
        if(!s.voiceEnabled) return reply('Voice AI is disabled in the dashboard.');
        const member=await i.guild.members.fetch(i.user.id);
        if(i.options.getSubcommand()==='leave') {leaveVoice(i.guildId);return reply('Voice AI stopped and left the channel.');}
        if(!member.voice.channel) return reply('Join a voice channel first.');
        if(!member.voice.channel.joinable || !member.voice.channel.speakable) return reply('I need Connect and Speak permissions.');
        await joinVoice(member.voice.channel,i.channel,s);
        return reply('🎙️ Voice AI joined. Everyone here can see that it is listening for speech. Use `/voice leave` to stop.');
      }
      case 'warn': {
        if(!i.memberPermissions.has(PermissionsBitField.Flags.ModerateMembers)) return reply('Permission denied.');
        if(user.id===i.user.id || user.bot) return reply('Choose another human member.');
        warn(i.guildId,user.id,i.user.id,reason); await log(i.guild,'warn',{userId:user.id,moderatorId:i.user.id,reason});return reply(`Warned ${user.username}.`);
      }
      case 'warnings': return reply(warnings(i.guildId,user.id).map(w=>`#${w.id} ${w.at}: ${w.reason}`).join('\n')||'No warnings.');
      case 'clear': {
        if(!i.memberPermissions.has(PermissionsBitField.Flags.ManageMessages)) return reply('Permission denied.');
        const count=i.options.getInteger('count'); const deleted=await i.channel.bulkDelete(count,true);
        await log(i.guild,'clear',{moderatorId:i.user.id,count:deleted.size});return reply(`Deleted ${deleted.size} messages.`);
      }
      case 'timeout': case 'kick': case 'ban': {
        const needed={timeout:PermissionsBitField.Flags.ModerateMembers,kick:PermissionsBitField.Flags.KickMembers,ban:PermissionsBitField.Flags.BanMembers}[i.commandName];
        if(!i.memberPermissions.has(needed)) return reply('Permission denied.');
        const member=await i.guild.members.fetch(user.id).catch(()=>null);
        if(!member || member.id===i.user.id || member.id===i.guild.ownerId || !member.moderatable && i.commandName==='timeout' || !member.kickable && i.commandName==='kick' || !member.bannable && i.commandName==='ban') return reply('Cannot moderate this member; check role hierarchy.');
        if(i.commandName==='timeout') await member.timeout(i.options.getInteger('minutes')*60000,reason);
        if(i.commandName==='kick') await member.kick(reason);
        if(i.commandName==='ban') await member.ban({reason});
        await log(i.guild,i.commandName,{userId:user.id,moderatorId:i.user.id,reason});return reply(`${i.commandName}: ${user.username}`);
      }
    }
  } catch(e) {console.error('Command:',e);await reply('Action failed. Check bot permissions and configuration.').catch(()=>{});}
});
export async function startBot(){await client.login(env.token);}
