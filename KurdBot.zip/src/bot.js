import {Client,GatewayIntentBits as I,Events,Partials,PermissionFlagsBits as P,EmbedBuilder,ActionRowBuilder,ButtonBuilder,ButtonStyle} from 'discord.js';
import {commands} from './commands.js';
import {attachSecurity,verifyMember} from './security.js';
import {scan,lockdown} from './operations.js';
import {plan} from './db.js';
import {entitled} from './catalog.js';
import {env} from './config.js';
import {room,playback} from './cinema.js';
import {createWatch} from './watch.js';
export const client=new Client({intents:[I.Guilds,I.GuildMembers,I.GuildMessages,I.MessageContent,I.GuildVoiceStates,I.GuildModeration],partials:[Partials.Message,Partials.Channel]});
attachSecurity(client);
client.once(Events.ClientReady,async c=>{console.log(`VEX ready as ${c.user.tag}`);c.user.setActivity('VEX Security | /security');try{await c.application.fetch();await c.application.commands.set(commands);}catch(e){console.error('Command registration:',e.message);}});
client.on(Events.InteractionCreate,async i=>{
 if(!i.isChatInputCommand()||!i.guild)return;await i.deferReply(['cinema','watch'].includes(i.commandName)&&!i.options.getBoolean('private')?{}:{flags:64});
 try{
  const actor=await i.guild.members.fetch({user:i.user.id,force:true});let result;
  if(i.commandName==='security'){if(!actor.permissions.has(P.ManageGuild))throw Error('Manage Server required');result=`VEX Security • ${plan(i.guildId)}\n${env.publicUrl}`;}
  else if(i.commandName==='verify'){if(!actor.permissions.has(P.ModerateMembers))throw Error('Moderate Members required');await verifyMember(i.guild,actor,await i.guild.members.fetch(i.options.getUser('member',true).id));result='Member approved.';}
  else if(i.commandName==='scan'){if(!actor.permissions.has(P.Administrator)||!entitled(plan(i.guildId),'scanner'))throw Error('Administrator and Ultimate required');const s=scan(i.guild);result=`Configuration score: ${s.score}/100\n`+s.checks.map(c=>(c.ok?'✓ ':'✗ ')+c.name).join('\n');}
  else if(i.commandName==='lockdown'){if(actor.id!==i.guild.ownerId)throw Error('Server owner required');result=JSON.stringify(await lockdown(i.guild,i.options.getBoolean('enabled',true),actor.id));}
  else if(i.commandName==='cinema'){const r=playback(room(i.guildId));result=r.url?`🎬 **${r.title.replaceAll('*','')}** — ${r.waiting?`Starts <t:${Math.floor(r.scheduledAt/1000)}:F> • <t:${Math.floor(r.scheduledAt/1000)}:R>`:r.playing?'Playing now':'Paused'}\n${env.publicUrl}/cinema/${i.guildId}`:'The cinema is empty. A server administrator can schedule a movie in the VEX dashboard.';}
  else if(i.commandName==='watch'){
   const w=createWatch(env.publicUrl,i.guildId,i.user.id,i.options.getString('url',true),i.options.getString('title')||'');
   const embed=new EmbedBuilder().setColor(0x9b75ff).setAuthor({name:'VEX CINEMA • ڤێکس سینەما'}).setTitle('🎬 '+w.title).setURL(w.link).setDescription('Your movie is ready. Open the room to watch on your device.\nفیلمەکەت ئامادەیە؛ ژوورەکە بکەرەوە و سەیری بکە.').addFields({name:'🎞️ Watch mode / شێوازی سەیرکردن',value:'Personal playback • ماوەی لینک ٧ ڕۆژ',inline:true},{name:'🔗 Source / سەرچاوە',value:w.youtubeId?'YouTube':'Direct HTTPS video',inline:true}).setFooter({text:'VEX Cinema • Share videos you have permission to share'});
   embed.setThumbnail(w.youtubeId?'https://i.ytimg.com/vi/'+w.youtubeId+'/hqdefault.jpg':i.client.user.displayAvatarURL());
   const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('▶ Watch / سەیرکردن').setURL(w.link),new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('🎬 More / فیلمی تر').setURL(env.publicUrl+'/watch'));
   await i.editReply({embeds:[embed],components:[row],allowedMentions:{parse:[]}});return;
  }
  else result='This command was replaced. Use /security.';
  await i.editReply({content:String(result).slice(0,1900),allowedMentions:{parse:[]}});
 }catch(e){await i.editReply({content:e.message,allowedMentions:{parse:[]}}).catch(()=>{});}
});
export async function startBot(){await client.login(env.token);}
