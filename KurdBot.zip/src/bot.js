import {Client,GatewayIntentBits as I,Events,Partials,PermissionFlagsBits as P} from 'discord.js';
import {commands} from './commands.js';
import {attachSecurity,verifyMember} from './security.js';
import {scan,lockdown} from './operations.js';
import {plan} from './db.js';
import {entitled} from './catalog.js';
import {env} from './config.js';
import {room} from './cinema.js';
export const client=new Client({intents:[I.Guilds,I.GuildMembers,I.GuildMessages,I.MessageContent,I.GuildVoiceStates,I.GuildModeration],partials:[Partials.Message,Partials.Channel]});
attachSecurity(client);
client.once(Events.ClientReady,async c=>{console.log(`VEX ready as ${c.user.tag}`);c.user.setActivity('VEX Security | /security');try{await c.application.fetch();await c.application.commands.set(commands);}catch(e){console.error('Command registration:',e.message);}});
client.on(Events.InteractionCreate,async i=>{
 if(!i.isChatInputCommand()||!i.guild)return;await i.deferReply(i.commandName==='cinema'?{}:{flags:64});
 try{
  const actor=await i.guild.members.fetch({user:i.user.id,force:true});let result;
  if(i.commandName==='security'){if(!actor.permissions.has(P.ManageGuild))throw Error('Manage Server required');result=`VEX Security • ${plan(i.guildId)}\n${env.publicUrl}`;}
  else if(i.commandName==='verify'){if(!actor.permissions.has(P.ModerateMembers))throw Error('Moderate Members required');await verifyMember(i.guild,actor,await i.guild.members.fetch(i.options.getUser('member',true).id));result='Member approved.';}
  else if(i.commandName==='scan'){if(!actor.permissions.has(P.Administrator)||!entitled(plan(i.guildId),'scanner'))throw Error('Administrator and Ultimate required');const s=scan(i.guild);result=`Configuration score: ${s.score}/100\n`+s.checks.map(c=>(c.ok?'✓ ':'✗ ')+c.name).join('\n');}
  else if(i.commandName==='lockdown'){if(actor.id!==i.guild.ownerId)throw Error('Server owner required');result=JSON.stringify(await lockdown(i.guild,i.options.getBoolean('enabled',true),actor.id));}
  else if(i.commandName==='cinema'){const r=room(i.guildId);result=r.url?`🎬 **${r.title.replaceAll('*','')}** — Watch together: ${env.publicUrl}/cinema/${i.guildId}`:'The cinema is empty. A server admin can set a movie in the VEX dashboard.';}
  else result='This command was replaced. Use /security.';
  await i.editReply({content:String(result).slice(0,1900),allowedMentions:{parse:[]}});
 }catch(e){await i.editReply({content:e.message,allowedMentions:{parse:[]}}).catch(()=>{});}
});
export async function startBot(){await client.login(env.token);}
