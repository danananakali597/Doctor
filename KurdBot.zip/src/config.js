import 'dotenv/config';
export const env = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  clientSecret: process.env.DISCORD_CLIENT_SECRET,
  redirectUri: process.env.DISCORD_REDIRECT_URI || 'http://localhost:3000/auth/callback',
  openaiKey: process.env.OPENAI_API_KEY,
  secret: process.env.SESSION_SECRET,
  port: Number(process.env.PORT || 3000),
  publicUrl: process.env.PUBLIC_URL || 'http://localhost:3000',
  dataDir: process.env.DATA_DIR || './data',
  aiModel: process.env.AI_MODEL || 'gpt-4.1-mini',
  transcribeModel: process.env.TRANSCRIBE_MODEL || 'gpt-4o-mini-transcribe',
  ttsModel: process.env.TTS_MODEL || 'gpt-4o-mini-tts',
  ttsVoice: process.env.TTS_VOICE || 'alloy'
};
export function validateEnv() {
  for (const [key, value] of Object.entries({DISCORD_TOKEN:env.token, DISCORD_CLIENT_ID:env.clientId, DISCORD_CLIENT_SECRET:env.clientSecret, SESSION_SECRET:env.secret})) {
    if (!value || (key === 'SESSION_SECRET' && value.length < 32)) throw new Error(`Set ${key} in .env (SESSION_SECRET must be at least 32 characters)`);
  }
  if (!['http:', 'https:'].includes(new URL(env.publicUrl).protocol)) throw new Error('Invalid PUBLIC_URL');
  if (new URL(env.publicUrl).hostname !== 'localhost' && !env.publicUrl.startsWith('https://')) throw new Error('PUBLIC_URL must use HTTPS outside localhost');
}
