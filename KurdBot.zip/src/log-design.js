// Shared severity palette; saved legacy custom colors never override risk colors.
export const logPalette=Object.freeze({normal:'#3498db',warning:'#f39c12',danger:'#e74c3c'});
const warnings=new Set(['message_deleted','messages_bulk_deleted','member_banned','member_kicked','members_pruned','timeout_given','channel_deleted','channel_permissions_changed','role_deleted','webhook_created','webhook_updated','webhook_deleted','automod_rule_deleted','message_violation','join_protection','voice_spam','security_configuration_changed']);
const dangers=new Set(['security_incident','risk_escalation','bot_roles_changed','bot_removed','emergency_lockdown']);
export function logSeverity(id,details={},significant=false){
 if(dangers.has(id))return 'danger';
 const rules=String(details.rules||'').split(',').map(x=>x.trim());
 if(rules.some(x=>['raid','nuke','massModeration','permissions','protected','scam','urls'].includes(x)))return 'danger';
 return warnings.has(id)||significant?'warning':'normal';
}
const labels={actor:'Actor',author:'Author',member:'Member',target:'Target',channel:'Channel',before:'Before',after:'After',message:'Message ID',audit_entry:'Audit entry',account_created:'Account created',accountDays:'Account age (days)'};
const titleCase=s=>s.replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());
function fieldValue(key,value){
 const text=String(value).slice(0,500);
 if(/^\d{17,22}$/.test(text)){
  if(['actor','author','member'].includes(key))return `<@${text}>`;
  if(['channel','from','to','parent'].includes(key))return `<#${text}>`;
 }
 return text||'—';
}
export function buildLogEmbed(guild,id,details={},options={}){
 const severity=logSeverity(id,details,options.significant);
 const icon=severity==='danger'?'🚨':severity==='warning'?'⚠️':'ℹ️';
 const fields=Object.entries(details).filter(([key,value])=>!['avatar_url','thumbnail_url'].includes(key)&&value!==null&&value!==undefined).slice(0,20).map(([key,value])=>({name:labels[key]||titleCase(key),value:fieldValue(key,value),inline:!['before','after','note','reason','changed','rules','result'].includes(key)&&String(value).length<80}));
 let remaining=5000;
 const boundedFields=fields.flatMap(field=>{if(remaining<=field.name.length)return [];const value=field.value.slice(0,remaining-field.name.length);remaining-=field.name.length+value.length;return [{...field,value}];});
 const userId=details.author||details.member||details.actor;
 const user=guild.members?.cache?.get(userId)?.user;
 const avatar=user?.displayAvatarURL?.({size:128});
 return {title:`${icon} ${options.title||titleCase(id)}`,color:parseInt(logPalette[severity].slice(1),16),fields:boundedFields,timestamp:new Date().toISOString(),footer:{text:`VEX • ${titleCase(options.group||'security')} Logs • ${severity==='normal'?'Normal':severity==='warning'?'Warning':'High Risk'}`},...(avatar?{thumbnail:{url:avatar}}:{})};
}
