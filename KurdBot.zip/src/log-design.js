// Shared severity palette; saved legacy custom colors never override risk colors.
export const logPalette=Object.freeze({normal:'#3498db',warning:'#f39c12',danger:'#e74c3c'});
const warnings=new Set(['message_deleted','messages_bulk_deleted','member_banned','member_kicked','members_pruned','timeout_given','channel_deleted','channel_permissions_changed','role_deleted','webhook_created','webhook_updated','webhook_deleted','automod_rule_deleted','message_violation','join_protection','voice_spam','security_configuration_changed']);
const dangers=new Set(['security_incident','risk_escalation','bot_roles_changed','bot_removed','emergency_lockdown']);
export function logSeverity(id,details={},significant=false){
 if(dangers.has(id))return 'danger';
 const rules=String(details.rules||'').split(',').map(x=>x.trim());
 if(rules.some(x=>['raid','nuke','massModeration','permissions','protected','scam','urls'].includes(x)))return 'danger';
 return warnings.has(id)||significant?'warning':'normal';
}
const labels={content:'Message content',attachments:'Attachments',deleted_by:'Deleted by',actor:'Actor',author:'Author',member:'Member',target:'Target',channel:'Channel',before:'Before',after:'After',message:'Message ID',message_content:'Message',before_content:'Before',after_content:'After',deleted_by:'Deleted by',edited_by:'Edited by',deletion_audit_actor:'Matching deletion audit',audit_entry:'Audit entry',account_created:'Account created',accountDays:'Account age (days)'};
const titleCase=s=>s.replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());
function fieldValue(key,value,id){
 const text=String(value).slice(0,1000);
 if(['message_content','before_content','after_content'].includes(key))return '```'+text.replaceAll('`','ˋ').slice(0,970)+'```';
 if(/^\d{17,22}$/.test(text)){
  if(['actor','author','member','deleted_by','edited_by','deletion_audit_actor'].includes(key))return `<@${text}>`;
  if(['channel','from','to','parent'].includes(key))return `<#${text}>`;
  if(key==='target'&&/^(member_|timeout_|verification_)/.test(id))return `<@${text}>`;
  if(key==='target'&&id.startsWith('role_'))return `<@&${text}>`;
  if(key==='target'&&/^(channel_|thread_)/.test(id))return `<#${text}>`;
 }
 return text||'—';
}
export function buildLogEmbed(guild,id,details={},options={}){
 const severity=logSeverity(id,details,options.significant);
 const icon=id==='message_deleted'?'🗑️':id==='message_edited'?'✏️':severity==='danger'?'🚨':severity==='warning'?'⚠️':'ℹ️';
 const fields=Object.entries(details).filter(([key,value])=>!['avatar_url','thumbnail_url'].includes(key)&&value!==null&&value!==undefined).slice(0,20).flatMap(([key,value])=>{
  if(key==='content'){const text=String(value).slice(0,4000);return Array.from({length:Math.max(1,Math.ceil(text.length/1000))},(_,i)=>({name:i?'Message content (continued)':'Message content',value:text.slice(i*1000,(i+1)*1000)||'—',inline:false}));}
  return [{name:key==='deleted_by'&&/^\d{17,22}$/.test(String(value))?'Deleted by (audit match)':labels[key]||titleCase(key),value:fieldValue(key,value,id),inline:!['content','attachments','deleted_by','before','after','message_content','before_content','after_content','deletion_audit_actor','note','reason','changed','rules','result'].includes(key)&&String(value).length<80}];
 });
 let remaining=5000;
 const boundedFields=fields.flatMap(field=>{if(remaining<=field.name.length)return [];const value=field.value.slice(0,remaining-field.name.length);remaining-=field.name.length+value.length;return [{...field,value}];});
 const userId=details.author||details.member||details.actor;
 const user=guild.members?.cache?.get(userId)?.user;
 const avatar=details.avatar_url||user?.displayAvatarURL?.({size:128});
 return {title:`${icon} ${titleCase(options.title||id)}`,color:parseInt(logPalette[severity].slice(1),16),fields:boundedFields,timestamp:new Date().toISOString(),footer:{text:`VEX • ${titleCase(options.group||'security')} Logs • ${severity==='normal'?'Normal':severity==='warning'?'Warning':'High Risk'}`},...(avatar?{thumbnail:{url:avatar}}:{})};
}
