import {Readable} from 'node:stream';
import {joinVoiceChannel,createAudioPlayer,createAudioResource,EndBehaviorType,getVoiceConnection,VoiceConnectionStatus,entersState} from '@discordjs/voice';
import prism from 'prism-media';
import {ai,answer} from './ai.js';
import {env} from './config.js';

const sessions=new Map();
function wav(pcm) {
  const head=Buffer.alloc(44);head.write('RIFF');head.writeUInt32LE(36+pcm.length,4);head.write('WAVEfmt ',8);head.writeUInt32LE(16,16);head.writeUInt16LE(1,20);head.writeUInt16LE(2,22);head.writeUInt32LE(48000,24);head.writeUInt32LE(192000,28);head.writeUInt16LE(4,32);head.writeUInt16LE(16,34);head.write('data',36);head.writeUInt32LE(pcm.length,40);return Buffer.concat([head,pcm]);
}
export function leaveVoice(id) {const session=sessions.get(id);if(session) {session.active=false;session.connection.destroy();sessions.delete(id);} else getVoiceConnection(id)?.destroy();}
export async function joinVoice(channel,textChannel) {
  if(!ai) throw new Error('OPENAI_API_KEY is needed for voice');
  leaveVoice(channel.guild.id);
  const connection=joinVoiceChannel({channelId:channel.id,guildId:channel.guild.id,adapterCreator:channel.guild.voiceAdapterCreator,selfDeaf:false});
  try {await entersState(connection,VoiceConnectionStatus.Ready,15000);} catch(e){connection.destroy();throw e;}
  const player=createAudioPlayer(); connection.subscribe(player);
  const session={active:true,connection,player,busy:false,users:new Set(),last:new Map()};sessions.set(channel.guild.id,session);
  // Visible announcement is required before receiving any audio; no raw recording is stored.
  await textChannel.send({content:`🎙️ **Voice AI is active in ${channel.name}.** It listens to speech to answer aloud. Voice is sent for transcription and is not saved. Use /voice leave to stop.`,allowedMentions:{parse:[]}});
  connection.receiver.speaking.on('start',userId=>{
    if(!session.active || session.busy || session.users.has(userId) || Date.now()-(session.last.get(userId)||0)<12000) return;
    const member=channel.members.get(userId); if(!member || member.user.bot) return;
    session.users.add(userId);
    const opus=connection.receiver.subscribe(userId,{end:{behavior:EndBehaviorType.AfterSilence,duration:900}});
    const decoder=new prism.opus.Decoder({rate:48000,channels:2,frameSize:960});
    const chunks=[];let bytes=0;let stopped=false;
    const stop=()=>{stopped=true;opus.destroy();decoder.destroy();};
    opus.pipe(decoder);
    decoder.on('data',b=>{bytes+=b.length;if(bytes>1920000) stop();else chunks.push(b);}); // max 10 seconds
    decoder.on('error',()=>{session.users.delete(userId);});
    decoder.on('end',async()=>{
      session.users.delete(userId);
      if(stopped || !session.active || session.busy || bytes<19200) return;
      session.busy=true;session.last.set(userId,Date.now());
      try {
        const audio=new File([wav(Buffer.concat(chunks))],'voice.wav',{type:'audio/wav'});
        const transcript=await ai.audio.transcriptions.create({file:audio,model:env.transcribeModel});
        const words=transcript.text?.trim();
        if(!words || words.length<2 || !session.active) return;
        const {settings}=await import('./db.js');const s=settings(channel.guild.id);
        if(!s.voiceEnabled) return;
        const language={ku:'Sorani Kurdish',en:'English',ar:'Arabic'}[s.voiceLanguage];
        const response=await answer(channel.guild.id,channel.id,userId,words,s.personality+` Keep voice replies under 50 words.${language?' Reply in '+language+'.':''}`);
        if(!session.active) return;
        const speech=await ai.audio.speech.create({model:env.ttsModel,voice:env.ttsVoice,input:response.slice(0,500),response_format:'mp3'});
        if(session.active) player.play(createAudioResource(Readable.from([Buffer.from(await speech.arrayBuffer())])));
      } catch(e){console.error('Voice AI:',e);await textChannel.send('Voice AI could not process that speech.').catch(()=>{});}
      finally {session.busy=false;}
    });
  });
  connection.on(VoiceConnectionStatus.Destroyed,()=>{session.active=false;sessions.delete(channel.guild.id);});
}
