import crypto from 'node:crypto';
import {env} from './config.js';

const signature=data=>crypto.createHmac('sha256',env.secret).update(data).digest('base64url');
export function issueActivitySession(guild,user){
 const body=Buffer.from(JSON.stringify({guild,user,until:Date.now()+3600000})).toString('base64url');
 return body+'.'+signature(body);
}
export function verifyActivitySession(token){
 if(typeof token!=='string'||token.length>800)return null;
 const [body,mac,...extra]=token.split('.');
 if(extra.length||!body||!mac||!/^[A-Za-z0-9_-]+$/.test(body)||!/^[A-Za-z0-9_-]+$/.test(mac))return null;
 const expected=signature(body),a=Buffer.from(mac),b=Buffer.from(expected);
 if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;
 try{const data=JSON.parse(Buffer.from(body,'base64url').toString('utf8'));
  return /^\d{17,22}$/.test(data.guild)&&/^\d{17,22}$/.test(data.user)&&data.until>Date.now()&&data.until<Date.now()+3600001?data:null;
 }catch{return null;}
}
