import {Events,AuditLogEvent as A} from 'discord.js';
import {settings,event} from './db.js';
import {logById} from './log-catalog.js';
const auditNames={GuildUpdate:'server_updated',MemberKick:'member_kicked',MemberPrune:'members_pruned',MemberBanAdd:'member_banned',MemberBanRemove:'member_unbanned',MemberMove:'member_moved_by_moderator',MemberDisconnect:'member_disconnected_by_moderator',ChannelOverwriteCreate:'channel_permissions_changed',ChannelOverwriteUpdate:'channel_permissions_changed',ChannelOverwriteDelete:'channel_permissions_changed'};
for(const [prefix,label] of [['Invite','invite'],['Webhook','webhook'],['Emoji','emoji'],['Sticker','sticker'],['GuildScheduledEvent','scheduled_event'],['AutoModerationRule','automod_rule']])for(const [suffix,verb]of [['Create','created'],['Update','updated'],['Delete','deleted']])auditNames[prefix+suffix]=label+'_'+verb;
export const auditTypes=new Map(Object.entries(auditNames).filter(([key])=>typeof A[key]==='number').map(([key,value])=>[A[key],value]));
export function logSetting(guildId,id){const rule=settings(guildId).activityLogs[id];return rule?.enabled?rule:null;}
export async function serverLog(guild,id,details={}){
 const config=logSetting(guild.id,id),spec=logById[id];if(!config||!spec)return;
 const safe=Object.fromEntries(Object.entries(details).filter(([,v])=>v!==null&&v!==undefined).slice(0,20).map(([k,v])=>[k,String(v).slice(0,500)]));
 event(guild.id,'server_'+id,{category:spec.group,...safe});
 const channel=guild.channels.cache.get(config.channelId);if(!channel||![0,5].includes(channel.type))return;
 try{await channel.send({embeds:[{author:{name:'VEX · SERVER LOGS'},title:spec.name,color:parseInt(config.color.slice(1),16),fields:Object.entries(safe).map(([name,value])=>({name:name.replaceAll('_',' '),value:value||'—',inline:value.length<80})),timestamp:new Date().toISOString(),footer:{text:spec.group.toUpperCase()+' · '+guild.name}}],allowedMentions:{parse:[]}});}
 catch(e){console.warn('Server log delivery failed:',id,e.code||'unknown');}
}
export function attachServerLogs(client){
 const on=(name,fn)=>client.on(name,(...args)=>void Promise.resolve().then(()=>fn(...args)).catch(e=>console.error('Server log handler:',name,e.code||e.name)));
 const send=(guild,id,details)=>guild?serverLog(guild,id,details):undefined;
 on(Events.GuildMemberAdd,m=>send(m.guild,'member_joined',{member:m.id,account_created:new Date(m.user.createdTimestamp).toISOString()}));
 on(Events.GuildMemberRemove,m=>send(m.guild,'member_left',{member:m.id}));
 on(Events.GuildMemberUpdate,async(before,after)=>{
  if(before.nickname!==after.nickname)await send(after.guild,'nickname_changed',{member:after.id,before:before.nickname||before.user.username,after:after.nickname||after.user.username});
  const added=after.roles.cache.filter(r=>!before.roles.cache.has(r.id)).map(r=>r.id),removed=before.roles.cache.filter(r=>!after.roles.cache.has(r.id)).map(r=>r.id);
  if(added.length||removed.length)await send(after.guild,'member_roles_changed',{member:after.id,added:added.join(', ')||'—',removed:removed.join(', ')||'—'});
  const old=before.communicationDisabledUntilTimestamp||0,next=after.communicationDisabledUntilTimestamp||0;
  if(old!==next)await send(after.guild,next>Date.now()?'timeout_given':'timeout_removed',{member:after.id,until:next?new Date(next).toISOString():'—'});
 });
 on(Events.MessageUpdate,(before,after)=>{if(after.author?.bot||before.content===after.content)return;return send(after.guild,'message_edited',{author:after.author?.id,channel:after.channelId,message:after.id,note:'Message content is not stored.'});});
 on(Events.MessageDelete,m=>{if(m.author?.bot)return;return send(m.guild,'message_deleted',{author:m.author?.id,channel:m.channelId,message:m.id});});
 on(Events.MessageBulkDelete,(messages,channel)=>send(channel.guild,'messages_bulk_deleted',{channel:channel.id,count:messages.size}));
 on(Events.ChannelPinsUpdate,(channel,time)=>send(channel.guild,'pins_changed',{channel:channel.id,last_pin:time?.toISOString()}));
 for(const [name,id]of [[Events.ChannelCreate,'channel_created'],[Events.ChannelDelete,'channel_deleted'],[Events.ThreadDelete,'thread_deleted'],[Events.GuildRoleCreate,'role_created'],[Events.GuildRoleDelete,'role_deleted']])on(name,item=>send(item.guild,id,{target:item.id,name:item.name}));
 on(Events.ThreadCreate,(thread,newlyCreated)=>newlyCreated?send(thread.guild,'thread_created',{target:thread.id,name:thread.name,parent:thread.parentId}):undefined);
 for(const [name,id]of [[Events.ChannelUpdate,'channel_updated'],[Events.ThreadUpdate,'thread_updated'],[Events.GuildRoleUpdate,'role_updated']])on(name,(before,after)=>{
  const keys=['name','type','topic','parentId','rateLimitPerUser','nsfw','archived','locked','autoArchiveDuration','color','hoist','mentionable'];
  const changes=keys.filter(k=>before[k]!==after[k]).map(k=>k);
  if(before.permissions?.bitfield!==after.permissions?.bitfield)changes.push('permissions');
  if(!changes.length)return;return send(after.guild,id,{target:after.id,name:after.name,changed:changes.join(', ')});
 });
 on(Events.VoiceStateUpdate,async(before,after)=>{
  if(before.channelId!==after.channelId)await send(after.guild,!before.channelId?'voice_joined':!after.channelId?'voice_left':'voice_moved',{member:after.id,from:before.channelId,to:after.channelId});
  if(before.selfMute!==after.selfMute||before.serverMute!==after.serverMute)await send(after.guild,'voice_mute_changed',{member:after.id,self_muted:after.selfMute,server_muted:after.serverMute});
  if(before.selfDeaf!==after.selfDeaf||before.serverDeaf!==after.serverDeaf)await send(after.guild,'voice_deaf_changed',{member:after.id,self_deafened:after.selfDeaf,server_deafened:after.serverDeaf});
 });
 on(Events.GuildAuditLogEntryCreate,(entry,guild)=>{
  if(Date.now()-entry.createdTimestamp>30000)return;
  const id=auditTypes.get(entry.action);if(!id)return;
  return send(guild,id,{actor:entry.executorId,target:entry.targetId,audit_entry:entry.id,reason:entry.reason,count:entry.extra?.count,channel:entry.extra?.channel?.id,changed:entry.changes?.map(c=>c.key).join(', ')});
 });
}
