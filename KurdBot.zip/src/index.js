import {validateEnv} from './config.js';
import {startBot} from './bot.js';
import {startWeb} from './web.js';
validateEnv();
startWeb();
startBot().catch(e=>{console.error('Bot login failed:',e);process.exit(1);});
