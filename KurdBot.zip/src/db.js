import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { env } from './config.js';

fs.mkdirSync(env.dataDir, {recursive:true, mode:0o700});
const db = new Database(path.join(env.dataDir, 'kurdbot.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS guild_settings (guild_id TEXT PRIMARY KEY, json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT NOT NULL, kind TEXT NOT NULL, detail TEXT NOT NULL, at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS events_guild ON events(guild_id,id);
CREATE TABLE IF NOT EXISTS warnings (id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT NOT NULL, user_id TEXT NOT NULL, moderator_id TEXT NOT NULL, reason TEXT NOT NULL, at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS conversations (guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, user_id TEXT NOT NULL, turns TEXT NOT NULL, updated_at INTEGER NOT NULL, PRIMARY KEY(guild_id,channel_id,user_id));`);

export const defaults = Object.freeze({aiEnabled:true, voiceEnabled:false, safetyEnabled:false, safetyMode:'review', aiChannelId:'', logsChannelId:'', personality:'You are KurdBot, a warm, concise assistant for a friends Discord server. Reply in the language of the user, including Sorani Kurdish, Arabic or English.', voiceLanguage:'auto'});
export function cleanSettings(input) {
  const x = {...defaults};
  for (const k of ['aiEnabled','voiceEnabled','safetyEnabled']) if (typeof input[k] === 'boolean') x[k] = input[k];
  if (['review','delete'].includes(input.safetyMode)) x.safetyMode = input.safetyMode;
  for (const k of ['aiChannelId','logsChannelId']) if (typeof input[k] === 'string' && /^\d{17,22}$|^$/.test(input[k])) x[k] = input[k];
  if (typeof input.personality === 'string') x.personality = input.personality.slice(0,1000).trim() || defaults.personality;
  if (['auto','ku','en','ar'].includes(input.voiceLanguage)) x.voiceLanguage = input.voiceLanguage;
  return x;
}
export function settings(id) {
  const row = db.prepare('SELECT json FROM guild_settings WHERE guild_id=?').get(id);
  return cleanSettings(row ? JSON.parse(row.json) : {});
}
export function saveSettings(id, patch) {
  const x = cleanSettings({...settings(id),...patch});
  db.prepare('INSERT INTO guild_settings VALUES (?,?) ON CONFLICT(guild_id) DO UPDATE SET json=excluded.json').run(id,JSON.stringify(x));
  return x;
}
export function event(guildId,kind,detail) {
  db.prepare('INSERT INTO events(guild_id,kind,detail) VALUES (?,?,?)').run(guildId,kind,JSON.stringify(detail));
  db.prepare('DELETE FROM events WHERE guild_id=? AND id NOT IN (SELECT id FROM events WHERE guild_id=? ORDER BY id DESC LIMIT 1000)').run(guildId,guildId);
}
export function events(id,limit=50) {return db.prepare('SELECT * FROM events WHERE guild_id=? ORDER BY id DESC LIMIT ?').all(id,Math.min(limit,100)).map(x=>({...x,detail:JSON.parse(x.detail)}));}
export function warn(guildId,userId,moderatorId,reason) {db.prepare('INSERT INTO warnings(guild_id,user_id,moderator_id,reason) VALUES (?,?,?,?)').run(guildId,userId,moderatorId,reason); event(guildId,'warn',{userId,moderatorId,reason});}
export function warnings(guildId,userId) {return db.prepare('SELECT * FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 10').all(guildId,userId);}
export function turns(guildId,channelId,userId) {
  const row=db.prepare('SELECT turns,updated_at FROM conversations WHERE guild_id=? AND channel_id=? AND user_id=?').get(guildId,channelId,userId);
  return row && Date.now()-row.updated_at<86400000 ? JSON.parse(row.turns) : [];
}
export function saveTurns(guildId,channelId,userId,list) {
  db.prepare('INSERT INTO conversations VALUES (?,?,?,?,?) ON CONFLICT(guild_id,channel_id,user_id) DO UPDATE SET turns=excluded.turns,updated_at=excluded.updated_at').run(guildId,channelId,userId,JSON.stringify(list.slice(-10)),Date.now());
  db.prepare('DELETE FROM conversations WHERE updated_at < ?').run(Date.now()-86400000);
}
