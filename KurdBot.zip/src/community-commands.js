import {SlashCommandBuilder as S,PermissionFlagsBits as P} from 'discord.js';
const simple=(name,description)=>new S().setName(name).setDescription(description).setDMPermission(false);
export const communityCommands=[
 simple('community','Open the VEX community command hub'),simple('ping','Check the VEX connection pulse'),simple('server','View this server’s profile'),
 ...['member','avatar','rank'].map(name=>simple(name,({member:'View a member profile',avatar:'View a member avatar',rank:'View an XP milestone card'})[name]).addUserOption(o=>o.setName('member').setDescription('Choose a member'))),
 simple('leaderboard','See the community XP leaderboard'),simple('roles','Choose your community roles'),simple('ticket','Open a private support ticket'),
 simple('invite','Create a limited-use invitation').setDefaultMemberPermissions(P.CreateInstantInvite),
 simple('room','Manage your personal VEX voice room').addStringOption(o=>o.setName('action').setDescription('Room action').setRequired(true).addChoices(...['lock','unlock','rename'].map(x=>({name:x,value:x})))).addStringOption(o=>o.setName('name').setDescription('New room name').setMaxLength(80)),
 simple('moderate','Take a recorded moderation action').setDefaultMemberPermissions(P.ModerateMembers).addStringOption(o=>o.setName('action').setDescription('Action').setRequired(true).addChoices(...['warn','timeout','untimeout','kick','ban','unban','clear'].map(x=>({name:x,value:x})))).addStringOption(o=>o.setName('member_id').setDescription('Member ID (not needed for clear)').setMaxLength(22)).addStringOption(o=>o.setName('reason').setDescription('Reason shown in the casebook').setMaxLength(450)).addIntegerOption(o=>o.setName('minutes').setDescription('Timeout duration').setMinValue(1).setMaxValue(40320)).addIntegerOption(o=>o.setName('amount').setDescription('Messages to clear').setMinValue(1).setMaxValue(100)),
 simple('cases','Review recent moderation cases').setDefaultMemberPermissions(P.ModerateMembers)
].map(c=>c.toJSON());
