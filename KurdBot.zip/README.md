# KurdBot — Discord AI + Voice + Dashboard

بۆتی Discord بۆ سێرڤەری هاوڕێیان، لەگەڵ داشبۆردی وێب، AI، Voice AI، moderation، chat safety و logs.

## بەکارهێنان

1. [Discord Developer Portal](https://discord.com/developers/applications) بکەرەوە و **New Application** دروست بکە؛ لە Bot بەشی **Reset Token**، تۆکنەکە بگرە. لە Bot > Privileged Gateway Intents ئەمانە چالاک بکە: **Server Members Intent** و **Message Content Intent**. بۆتەکە لە OAuth2 > URL Generator بە `bot` و `applications.commands` بانگ بکە، بە مۆڵەتی View Channels, Send Messages, Read Message History, Manage Messages, Moderate Members, Kick Members, Ban Members, View Audit Log, Connect, Speak. هەرگیز تۆکنەکە لە چات یان گیت مەنووسە.
2. لە OAuth2 > Redirects ئەمە زیاد بکە: `http://localhost:3000/auth/callback`. Client ID و Client Secret ـەکە بگرە.
3. Node.js 22.12 یان نوێتر دابمەزرێنە. لە فۆڵدەری پڕۆژەدا: `npm ci`. فایلەکە `cp .env.example .env` دروست بکە و `DISCORD_TOKEN`، `DISCORD_CLIENT_ID`، `DISCORD_CLIENT_SECRET`، `SESSION_SECRET` و `OPENAI_API_KEY` تێدا دابنێ. بۆ SESSION_SECRET دەتوانیت `openssl rand -hex 32` بەکاربهێنیت. OpenAI API key لە پلاتفۆڕمی API دێت و پێویستی بە billing ـی جیاواز هەیە؛ ChatGPT Plus خۆی ئەو کلیلییە نادات.
4. `npm start` بەکاربهێنە، پاشان `http://localhost:3000` بکەرەوە و بە Discord بچۆ ژوورەوە. لە داشبۆرددا channel ـی logs دیاری بکە. Voice و Safety بە بنەڕەت ناچالاکن؛ ئەگەر دەتەوێت چالاکیان بکە.

## کۆماندەکان

`/help`, `/ping`, `/ai`, `/voice join`, `/voice leave`, `/serverinfo`, `/userinfo`, `/warn`, `/warnings`, `/clear`, `/timeout`, `/kick`, `/ban`. کۆماندەکانی مۆدێرەیشن مۆڵەتی خۆیان دەوێت؛ بۆتەکەش لە ڕیزبەندی role دا دەبێت بەرزتر بێت لە ئەندامی مەبەست.

## هۆستکردن

`docker compose up -d --build` پڕۆژەکە لەسەر VPS بەردەوام دەکات. `PUBLIC_URL` و `DISCORD_REDIRECT_URI` بۆ دۆمەینی HTTPS ـەکەت بگۆڕە و reverse proxy بە TLS لە پێش پۆرتی ناوخۆیی 3000 دابنێ. هەمان redirect URI لە Discord Developer Portal زیاد بکە. داتای SQLite لە Docker volume دا دەمێنێتەوە. پێش گۆڕینی هۆست backup لە volume بگرە.

## سنوورەکان

- هیچ تۆکنێک لەم پڕۆژەیەدا دانەنراوە؛ بێ تۆکن و API key، بۆتەکە لە سێرڤەرەکەت کار ناکات.
- Voice AI لە `/voice join` دەست پێ دەکات، بە ئاشکرا ئاگاداری دەدات و دەنگی خام پاش وەرگێڕان پاشەکەوت ناکات. وەڵامی دەنگی بە quality و پشتگیری زمانی خزمەتگوزارییەکە پەیوەستە؛ سۆرانی بە تایبەتی دەبێت بە گوێ تاقی بکرێتەوە.
- Chat safety بە بنەڕەت review ـە. هەڵەی AI ئەگەری هەیە؛ لە داشبۆرددا دەتوانیت deletion هەڵبژێریت. بۆ خوێندنەوەی هەموو پەیامەکان Message Content Intent پێویستە.
- Dashboard تەنها ئەو سێرڤەرانە نیشان دەدات کە بۆتەکە تێیاندایە و تۆ مۆڵەتی Manage Server ـت هەیە. Session دوای restart نوێ دەبێتەوە.

## پاراستنی نهێنی

`.env` و `data/` لە git دەرکراون. گفتوگۆی AI تەنها دە turn ـی دوایین، تا 24 کاتژمێر، لە SQLite دا هەڵدەگیرێت. Logs ناوەڕۆکی پەیام هەڵناگرن. AI و safety و دەنگ داتای پێویست بۆ OpenAI API دەنێرن، بەپێی ڕێکخستنەکانت.
